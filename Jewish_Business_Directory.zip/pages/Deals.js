
import React from 'react';

function Deals() {
  return (
    <div>
      <h1>Special Deals</h1>
      <p>View promotions from our businesses...</p>
    </div>
  );
}

export default Deals;
    