
import React from 'react';

function BusinessProfile() {
  return (
    <div>
      <h1>Business Profile</h1>
      <p>Detailed information about a business...</p>
    </div>
  );
}

export default BusinessProfile;
    