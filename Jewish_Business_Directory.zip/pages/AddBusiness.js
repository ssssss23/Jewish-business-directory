
import React from 'react';

function AddBusiness() {
  return (
    <div>
      <h1>Add Your Business</h1>
      <p>Submit your business details here...</p>
    </div>
  );
}

export default AddBusiness;
    