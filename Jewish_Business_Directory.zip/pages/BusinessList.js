
import React from 'react';

function BusinessList() {
  return (
    <div>
      <h1>Business Listings</h1>
      <p>Here are the businesses listed in the directory...</p>
    </div>
  );
}

export default BusinessList;
    