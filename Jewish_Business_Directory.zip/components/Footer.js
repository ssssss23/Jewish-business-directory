
import React from 'react';

function Footer() {
  return (
    <footer>
      <p>Jewish Business Directory &copy; 2025</p>
    </footer>
  );
}

export default Footer;
    